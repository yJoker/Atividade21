/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;
import java.sql.Date;
import java.time.LocalDate;

/**
 *
 * @author Aluno
 */
public class Funcionarios {
   private Integer ID;
   private String Nome;
   private Float Telefone;
   private LocalDate Data1;
   private Double Salario;
   private int CPF;
   private String Tipo;
  
    
   public Funcionarios(){
       
   }
   public Funcionarios(int idFunc, String Nome,Float Telefone, LocalDate Data1 ,Double Salario, int CPF,String Tipo){
    this.ID = idFunc;
    this.Nome = Nome;
    this.CPF = CPF;
    this.Data1 = Data1;
    this.Salario = Salario;
    this.Telefone = Telefone;
    this.Tipo = Tipo;
  
   }

    /**
     * @return the ID
     */
    public Integer getID() {
        return ID;
    }

    /**
     * @param ID the ID to set
     */
    public void setID(Integer ID) {
        this.ID = ID;
    }

    /**
     * @return the Nome
     */
    public String getNome() {
        return Nome;
    }

    /**
     * @param Nome the Nome to set
     */
    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    /**
     * @return the Telefone
     */
    public Float getTelefone() {
        return Telefone;
    }

    /**
     * @param Telefone the Telefone to set
     */
    public void setTelefone(Float Telefone) {
        this.Telefone = Telefone;
    }

    /**
     * @return the Data1
     */
    public LocalDate getData1() {
        return Data1;
    }

    /**
     * @param Data1 the Data1 to set
     */
    public void setData1(LocalDate Data1) {
        this.Data1 = Data1;
    }

    /**
     * @return the Salario
     */
    public Double getSalario() {
        return Salario;
    }

    /**
     * @param Salario the Salario to set
     */
    public void setSalario(Double Salario) {
        this.Salario = Salario;
    }

    /**
     * @return the CPF
     */
    public int getCPF() {
        return CPF;
    }

    /**
     * @param CPF the CPF to set
     */
    public void setCPF(int CPF) {
        this.CPF = CPF;
    }

    /**
     * @return the Tipo
     */
    public String getTipo() {
        return Tipo;
    }

    /**
     * @param Tipo the Tipo to set
     */
    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

   
    
       
   
}



