/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Telas;

import static Telas.FXMLCadastroController.StageCad;
import static Telas.FXMLSecundariaController.StageCad;
import static Telas.FXMLPainelController.StageCad;
import java.awt.Image;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 *
 * @author Aluno
 */


public class FXMLSecundariaController implements Initializable {
    
    @FXML
    private Label label;
    
    //Botoes
    @FXML private Button BtnCadastrar;
    @FXML private Button BtnRelatorio;
    @FXML private Button BtnPaineis;
    @FXML private Button BtnSair;
    @FXML private MenuBar MenuBarPrinc;   
    @FXML private MenuItem Cadastrar2; 
    @FXML private Menu Cadastrar1; 
    @FXML private MenuItem Relatorio2; 
    @FXML private Menu Relatorio1; 
    @FXML private MenuItem Painel2; 
    @FXML private Menu Painel1; 
    
    
    
    public static Stage StageCad; 
    private int i;
    
    @FXML
    public void Painel (Stage stage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("FXMLPainel.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Tela de Painel");
        stage.setScene(scene);
        stage.show();
        StageCad = stage;
            
    }
    
    @FXML
    public void Relatorio (Stage stage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("FXMLRelatorio.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Tela de Relatorio");
        stage.setScene(scene);
        stage.show();
        StageCad = stage;
            
    }
    
    @FXML
    public void Cadastro (Stage stage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("FXMLCadastro.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Tela de cadastro");
        stage.setScene(scene);
        stage.show();
        StageCad = stage;
            
    }
    
    @FXML
    public void Secundaria (Stage stage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("FXMLSecundaria.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Tela secundaria");
        stage.setScene(scene);
        stage.show();
        StageCad = stage;
            
    }
    
    
    @FXML
    private void Cadastrar1(ActionEvent event) throws Exception {
    //    BtnCadastrar.setOnMouseClicked((MouseEvent a) ->{
            FXMLCadastroController abre = new FXMLCadastroController();
           // try{
                abre.Cadastro (new Stage());
            //}catch(Exception ex){
           //     Logger.getLogger(FXMLSecundariaController.class.getName()).log(Level.SEVERE,null, ex);
                
         //   }
            
       // });
        
        
    }
    
    @FXML
    private void Relatorio(ActionEvent event) throws Exception {
       // BtnRelatorio.setOnMouseClicked((MouseEvent a) ->{
            FXMLRelatorioController abre = new FXMLRelatorioController();
       //     try{
                abre.Relatorio (new Stage());
       //    }catch(Exception ex){
         //       Logger.getLogger(FXMLSecundariaController.class.getName()).log(Level.SEVERE,null, ex);
                
      //      }
            
    //    });
        
        
    }
    
    @FXML
    private void Painel(ActionEvent event) throws Exception {
       // BtnPaineis.setOnMouseClicked((MouseEvent a) ->{
            FXMLPainelController abre = new FXMLPainelController();
         //   try{
                abre.Painel (new Stage());
          //  }catch(Exception ex){
          //      Logger.getLogger(FXMLSecundariaController.class.getName()).log(Level.SEVERE,null, ex);
                
       //     }
           
       // });
        
        
    }

    @FXML 
    public void SairStageCad(ActionEvent event){
         
         Platform.exit();
         
         
     }
    
    
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

   
    
}
