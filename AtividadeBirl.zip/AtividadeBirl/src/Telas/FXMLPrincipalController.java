/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Telas;

import static Telas.FXMLCadastroController.StageCad;
import static Telas.FXMLSecundariaController.StageCad;
import java.awt.Image;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import sun.plugin2.message.JavaObjectOpMessage;

/**
 *
 * @author Aluno
 */
public class FXMLPrincipalController implements Initializable {
    
    @FXML
    private Label label;
    //labels
    @FXML private Label UsuarioLogin;
    @FXML private Label UsuarioSenha;
    //Botoes
    @FXML private Button BtnCadastrar;
    @FXML private Button BtnCancelar;
    //Textos
    @FXML private TextField TxtUsuario;
    @FXML private PasswordField TxtSenha;
    
    
    
    public static Stage StageCad; 
    private int i;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
       if(TxtUsuario.getText().equals("Admin") && TxtSenha.getText().equals("Admin")){

          
           JOptionPane.showMessageDialog(null,"Logado com Sucesso !!","Sucesso",JOptionPane.INFORMATION_MESSAGE);
           
       }else {
           JOptionPane.showMessageDialog(null,"Login ou Senha inválidos.","",JOptionPane.ERROR_MESSAGE);
                        TxtUsuario.setText("");
                        TxtSenha.setText("");
                        System.exit(i);
             
  }
  
        
        BtnCadastrar.setOnMouseClicked((MouseEvent a) ->{
            
            FXMLSecundariaController abre = new FXMLSecundariaController();
            try{
                abre.Secundaria (new Stage());
            }catch(Exception ex){
               
                Logger.getLogger(FXMLPrincipalController.class.getName()).log(Level.SEVERE,null, ex);
                
            }
            
            
         
        });
       
        
    }
   @FXML
    public void SairStageCad(ActionEvent event){
         
         Platform.exit();
         
         
     }
    
  
  
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
       

    }
}   
    

