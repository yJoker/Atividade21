/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Telas;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Aluno
 */
public class Telaas extends Application {
    
    @Override
    
    //Responsavel pela tela, Sem stage nao abre a tela
    //o start da inicio da tela
    //o stage com letra minuscula serve para colocar os elementos na tela
    //o stage com maiuscula serve para a importação
    public void start(Stage stage) throws Exception {
        
        //Responsavel por Chamar/carregar o arquivo da tela
        Parent root = FXMLLoader.load(getClass().getResource("FXMLTelaPrincipal.fxml"));
        //scene é o cenario
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
       
        stage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
