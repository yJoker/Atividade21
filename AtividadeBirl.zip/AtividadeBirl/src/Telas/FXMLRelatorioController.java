/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Telas;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


/**
 *
 * @author Aluno
 */
public class FXMLRelatorioController implements Initializable {
    
    @FXML
    private Label label1;
    //Nome e sobrenome
   
   @FXML private Label data;
   @FXML private Label descricao;
    //tXT
   
   @FXML private TextArea Descricao;
   @FXML private DatePicker Data;
    //Botoes
   @FXML private Button BtnConfirmar;
   @FXML private Button BtnVoltar1;
   @FXML private Button BtnLimpar;
    
   public static Stage StageCad; 
   
   
   @FXML
     public void Relatorio (Stage stage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("FXMLRelatorio.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Tela Relatorio");
        stage.setScene(scene);
        stage.show();
        StageCad = stage;
            
    }
   
    
     @FXML
     public void VoltarStageCad(ActionEvent event){
         
         Parent root = null;
         
         try{
             StageCad.close();
             
         }catch(Exception e){
             e.printStackTrace();
         }
         
         
     }
     @FXML
     public void LimparStageCad(ActionEvent event){
        
         
       Descricao.setText("");
        Data.setValue(null);
         
         
     }
    
     
      
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    
}
