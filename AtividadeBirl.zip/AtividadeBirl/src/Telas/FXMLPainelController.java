/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Telas;

import Model.Funcionarios;
import static Telas.FXMLSecundariaController.StageCad;
import static java.lang.Double.parseDouble;
import static java.lang.Float.parseFloat;
import static java.lang.Integer.parseInt;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Alert; 
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.web.WebEvent;
import javafx.stage.Stage;
import java.sql.Date;
import java.time.LocalDate;
import javafx.beans.Observable;
import jdbc.FuncionariosDAO;
import static jdbc.FuncionariosDAO.insereFuncionarios;

/**
 * FXML Controller class
 *
 * @author Aluno
 */
public class FXMLPainelController implements Initializable {

   private ObservableList<String> TipoSexo = FXCollections.observableArrayList("Masculino", "Feminino");
    
   @FXML private Label Nome1;
   @FXML private Label Telefone1;
   @FXML private Label CPF1;
   @FXML private Label Data1;
   @FXML private Label Salario1;
   @FXML private Label Sexo1;
   
   @FXML private TextField TxtNome1;
   @FXML private TextField TxtTelefone1;
   @FXML private TextField TxtCPF1;
   @FXML private TextField TxtSalario;
   @FXML private DatePicker Data;
   @FXML ComboBox combxTipo;
   
   
    //Botoes
   @FXML private Button BtnCadastrar1;
   @FXML private Button BtnVoltar1;
   @FXML private Button BtnLimpar;
   
   @FXML public static Stage StageCad; 
   
   @FXML TableView<Funcionarios> TabelaID;
   @FXML TableColumn<Funcionarios,Integer>ColunaID;
   @FXML TableColumn<Funcionarios,String>ColunaNome;
   @FXML TableColumn<Funcionarios,Float>ColunaTelefone;
   @FXML TableColumn<Funcionarios,Date>ColunaData1;
   @FXML TableColumn<Funcionarios,Double>ColunaCpf;
   @FXML TableColumn<Funcionarios,Double>ColunaSalario;
   
   private ObservableList<Funcionarios> Funcionarios;
   public static Funcionarios selecionado;
    
   FuncionariosDAO dao = new FuncionariosDAO(); 
   
    @FXML
    public void Painel (Stage stage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("FXMLPainel.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Tela de Painel");
        stage.setScene(scene);
        stage.show();
        StageCad = stage;
            
    }
     @FXML
    public void LimparStageCad(ActionEvent event){
        
          TxtNome1.setText("");
          TxtCPF1.clear();
          TxtTelefone1.setText("");
          TxtSalario.setText("");  
          combxTipo.setValue(null);
          Data.setValue(null);
         
         
     }
    @FXML
    public void VoltarStageCad(ActionEvent event){
         
         Parent root = null;
         
         try{
             StageCad.close();
             
         }catch(Exception e){
             e.printStackTrace();
         }
         
         
     }
    @FXML
    private void CadastCaD(ActionEvent event){
         if(TxtNome1.getText().equals("") || TxtTelefone1.getText().equals("")
                || Data.getValue() == null || TxtSalario.getText().equals("") || TxtCPF1.getText().equals("")
                  || combxTipo.getValue() == null  ){
             
             
            Alert cad = new Alert(Alert.AlertType.WARNING);
           cad.setTitle("ATENÇÃO");
           cad.setHeaderText("Campos Vazios");
           cad.setContentText("Por favor, Nao deixe campos vazios");
           cad.showAndWait();        
             
         }try{
               Funcionarios fun = new Funcionarios();
               fun.setNome(TxtNome1.getText());
               fun.setTelefone(parseFloat(TxtTelefone1.getText()));
               fun.setData1(Data.getValue());
               fun.setSalario(parseDouble(TxtSalario.getText()));
               fun.setCPF(parseInt(TxtCPF1.getText()));
               fun.setTipo(combxTipo.getValue().toString());

               FuncionariosDAO.insereFuncionarios(fun);   
               
              Alert a = new Alert(Alert.AlertType.CONFIRMATION);
              a.setTitle("Verificacao de cadastro");
              a.setHeaderText("Cadastrado Com Sucesso");
              a.showAndWait();  
               
           }catch(Exception e){
               System.out.println("Birl : " + e.getMessage());
                
           }
        
            
        
         
     }
    
  

   
    
   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // TODO
       
        combxTipo.setItems(TipoSexo);
        
    }    

    

    

 
    
}
