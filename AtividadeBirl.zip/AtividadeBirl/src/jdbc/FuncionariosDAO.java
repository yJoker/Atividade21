/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package jdbc;

import Model.Funcionarios;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;

/**
 *
 * @author Aluno
 */
public class FuncionariosDAO {
    private static Connection c;
    
    public FuncionariosDAO(){
        FuncionariosDAO.c = ConnectionFactory.getConnection();
    }
    
    public static void insereFuncionarios(Funcionarios fun){
    String sql = "INSERT INTO Funcionarios(Nome, Telefone, Data1, Salario, CPF)"
            +"VALUES(?,?,?,?,?);";
    try{
            PreparedStatement stmt = c.prepareStatement(sql);
            
            stmt.setString(1, fun.getNome());
            stmt.setFloat(2, fun.getTelefone());
            stmt.setDate(3, Date.valueOf(fun.getData1()));
            stmt.setDouble(4, fun.getSalario());
            stmt.setInt(5, fun.getCPF()); 
            stmt.execute(); 
            stmt.close();
        }catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
}

   

   